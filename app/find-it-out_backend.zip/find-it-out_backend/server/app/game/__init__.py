from server.app.game.game_factory import GameFactory
from server.app.game.gamequeue import GameQueue

game_factory = GameFactory()
game_queue = GameQueue()
